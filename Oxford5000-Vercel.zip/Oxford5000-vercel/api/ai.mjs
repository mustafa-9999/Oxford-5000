// Vercel Function: streamed text tutor and JSON generation.
// Required env: OPENAI_API_KEY. Optional: OPENAI_TEXT_MODEL.
export default {
  async fetch(request) {
    if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) return json({ error: 'OPENAI_API_KEY is not configured in Vercel' }, 500);
    let body;
    try { body = await request.json(); } catch { return json({ error: 'Invalid JSON body' }, 400); }
    const prompt = typeof body.prompt === 'string' ? body.prompt.slice(0, 30000) : '';
    if (!prompt.trim()) return json({ error: 'A prompt is required' }, 400);
    const model = process.env.OPENAI_TEXT_MODEL || 'gpt-4.1-mini';
    const wantsStream = body.stream === true;
    let upstream;
    try {
      upstream = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], temperature: 0.65, stream: wantsStream }),
      });
    } catch { return json({ error: 'Could not reach the AI provider' }, 502); }
    if (!upstream.ok) {
      const detail = await upstream.text().catch(() => '');
      return json({ error: `AI provider returned ${upstream.status}`, detail: detail.slice(0, 1200) }, upstream.status);
    }
    if (!wantsStream) {
      const data = await upstream.json();
      return json({ text: data.choices?.[0]?.message?.content || '' });
    }
    const encoder = new TextEncoder();
    const decoder = new TextDecoder();
    const stream = new ReadableStream({
      async start(controller) {
        let buffer = '';
        try {
          for await (const chunk of upstream.body) {
            buffer += decoder.decode(chunk, { stream: true });
            const lines = buffer.split('\n'); buffer = lines.pop() || '';
            for (const line of lines) {
              if (!line.startsWith('data: ')) continue;
              const raw = line.slice(6).trim();
              if (raw === '[DONE]') { controller.enqueue(encoder.encode('data: [DONE]\n\n')); continue; }
              try {
                const event = JSON.parse(raw);
                const delta = event.choices?.[0]?.delta?.content;
                if (typeof delta === 'string' && delta) controller.enqueue(encoder.encode(`data: ${JSON.stringify({ text: delta })}\n\n`));
              } catch { /* ignore non-JSON keepalive lines */ }
            }
          }
          controller.close();
        } catch {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ error: 'Stream interrupted' })}\n\n`));
          controller.close();
        }
      },
    });
    return new Response(stream, { headers: { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', 'X-Accel-Buffering': 'no' } });
  },
};
function json(data, status = 200) {
  return Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } });
}
