// Vercel Function: creates a short-lived OpenAI Realtime client secret.
// Required env: OPENAI_API_KEY. Optional: OPENAI_REALTIME_MODEL.
export default {
  async fetch(request) {
    if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) return json({ error: 'OPENAI_API_KEY is not configured in Vercel' }, 500);
    let body = {};
    try { body = await request.json(); } catch { /* optional body */ }
    const level = typeof body.level === 'string' ? body.level.slice(0, 8) : 'A1';
    const instructions = typeof body.instructions === 'string' && body.instructions.trim()
      ? body.instructions.slice(0, 7000)
      : `You are a patient English teacher for an Arabic-speaking learner at CEFR ${level}. Speak clearly and naturally, correct important mistakes gently, explain briefly in Arabic when useful, and ask one follow-up question. Keep responses concise and allow interruptions.`;
    const session = {
      type: 'realtime',
      model: process.env.OPENAI_REALTIME_MODEL || 'gpt-realtime-2.1',
      instructions,
      audio: {
        input: { transcription: { model: 'gpt-4o-mini-transcribe' }, turn_detection: { type: 'server_vad', create_response: true, interrupt_response: true } },
        output: { voice: body.gender === 'm' ? 'cedar' : 'marin' },
      },
    };
    let response;
    try {
      response = await fetch('https://api.openai.com/v1/realtime/client_secrets', {
        method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ session }),
      });
    } catch { return json({ error: 'Could not reach the Realtime API' }, 502); }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return json({ error: data.error?.message || `Realtime API returned ${response.status}` }, response.status);
    return json({ value: data.value, expires_at: data.expires_at });
  },
};
function json(data, status = 200) { return Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } }); }
