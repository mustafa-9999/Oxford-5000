// Vercel TTS compatibility endpoint for the app's existing cloudSpeak() call.
// Required env: OPENAI_API_KEY. Optional env: OPENAI_TTS_MODEL.
// Note: the legacy OpenAI Speech API model currently used here has a published shutdown date;
// the live conversation button uses Realtime and is the preferred long-term voice path.
export default {
  async fetch(request) {
    if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) return json({ error: 'OPENAI_API_KEY is not configured in Vercel' }, 500);
    let body;
    try { body = await request.json(); } catch { return json({ error: 'Invalid JSON body' }, 400); }
    const input = typeof body.text === 'string' ? body.text.slice(0, 4000) : '';
    if (!input.trim()) return json({ error: 'Text is required' }, 400);
    const voice = body.gender === 'm' ? 'cedar' : 'marin';
    const accent = body.accent === 'gb' ? 'British English' : 'American English';
    let upstream;
    try {
      upstream = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: process.env.OPENAI_TTS_MODEL || 'gpt-4o-mini-tts', voice, input, instructions: `Speak clearly in a natural ${accent} accent, like a friendly English teacher.`, response_format: 'mp3' }),
      });
    } catch { return json({ error: 'Could not reach the speech provider' }, 502); }
    if (!upstream.ok) {
      const detail = await upstream.text().catch(() => '');
      return json({ error: `Speech provider returned ${upstream.status}`, detail: detail.slice(0, 1000) }, upstream.status);
    }
    return new Response(upstream.body, { headers: { 'Content-Type': 'audio/mpeg', 'Cache-Control': 'no-store' } });
  },
};
function json(data, status = 200) { return Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } }); }
